#include <iostream>
using namespace std;

class Room {
    float length, height, breadth;

public:
    void inputData() {
        cout << "Enter Length, Height, Breadth: ";
        cin >> length >> height >> breadth;
    }

    void calculateArea() {
        float area = length * breadth;
        cout << "Area of Room = " << area << endl;
    }

    void calculateVolume() {
        float volume = length * height * breadth;
        cout << "Volume of Room = " << volume << endl;
    }
};

int main() {
    Room r;
    r.inputData();
    r.calculateArea();
    r.calculateVolume();
    return 0;
}

