#include <iostream>
using namespace std;

class Distance {
    int meter, centimeter;

public:
    void getdistance() {
        cout << "Enter distance (meters and centimeters): ";
        cin >> meter >> centimeter;
    }

    void putdistance() {
        cout << "Distance = " << meter << " meters and " << centimeter << " centimeters" << endl;
    }

    void adddistance(Distance d1, Distance d2) {
        centimeter = d1.centimeter + d2.centimeter;
        meter = d1.meter + d2.meter + (centimeter / 100);
        centimeter = centimeter % 100;
    }
};

int main() {
    Distance d1, d2, d3;
    cout << "Enter first distance:\n";
    d1.getdistance();

    cout << "Enter second distance:\n";
    d2.getdistance();

    d3.adddistance(d1, d2);

    cout << "First Distance: ";
    d1.putdistance();
    cout << "Second Distance: ";
    d2.putdistance();
    cout << "Total Distance: ";
    d3.putdistance();

    return 0;
}

