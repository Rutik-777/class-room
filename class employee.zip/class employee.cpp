#include <iostream>
using namespace std;

class Employee {
    int eid;
    string ename, ecity;
    float sal, gross;

public:
    void getinfo() {
        cout << "Enter Employee ID: ";
        cin >> eid;
        cout << "Enter Name: ";
        cin >> ename;
        cout << "Enter City: ";
        cin >> ecity;
        cout << "Enter Basic Salary: ";
        cin >> sal;
    }

    void findGrossSal() {
        float TA = 0.05 * sal;
        float DA = 0.10 * sal;
        float HRA = 0.07 * sal;
        float EPF = 0.12 * sal;
        gross = sal + TA + DA + HRA - EPF;
    }

    void printinfo() {
        cout << "ID: " << eid << ", Name: " << ename << ", City: " << ecity
             << ", Gross Salary: " << gross << endl;
    }
};

int main() {
    Employee emp[2];
    for (int i = 0; i < 2; i++) {
        cout << "\nEnter details for Employee " << i + 1 << ":\n";
        emp[i].getinfo();
        emp[i].findGrossSal();
    }

    cout << "\nEmployee Details:\n";
    for (int i = 0; i < 2; i++) {
        emp[i].printinfo();
    }

    return 0;
}

